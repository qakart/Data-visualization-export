import expect from 'expect.js';

describe('suite', () => {
  it('is a test', () => {
    expect(true).to.equal(true);
  });
});
